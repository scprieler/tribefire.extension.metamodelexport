package com.braintribe.tribefire.cartridge.metamodelexport.tableau;

public class TableContext {

	public String id;
	public String alias;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	
	
	
}
